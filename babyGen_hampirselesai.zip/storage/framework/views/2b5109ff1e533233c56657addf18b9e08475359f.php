<!DOCTYPE html>
<html>

    
    
<body>

    

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babyGen\resources\views/layout/main.blade.php ENDPATH**/ ?>