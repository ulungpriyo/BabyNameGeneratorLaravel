
    

    <?php $__env->startSection('content'); ?>

    <section style="padding-top: 80px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            Details
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <td>Detail Post</td>
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <td><?php echo e($post->id); ?></td>
                                        <td><?php echo e($post->nama); ?></td>
                                        <td><?php echo e($post->asal_nama); ?></td>
                                        <td><?php echo e($post->personality); ?></td>
                                        <td><?php echo e($post->jenis_kelamin); ?></td>
                                        <td><?php echo e($post->arti_nama); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babyGen\resources\views/single-post.blade.php ENDPATH**/ ?>