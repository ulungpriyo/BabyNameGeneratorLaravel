
    

    <?php $__env->startSection('content'); ?>

<div class="wrapper">
<div class="jumbotron">
    <div class="pl-5" id="top">
    <h3 class="font-weight-bold">Hello Mom and Dad!</h3>
    <p class="lead" style="font-size: 22px;">Temukan Nama Terbaik untuk si Buah Hati Kecil</p>
    <hr class="my-4" width="450" align="left">
    <p>Mencoba untuk mendapatkan nama terbaik</p>
    <a class="btn btn-lg" href="generate" role="button"><font color="white">coba disini</font></a>
    </div>
    <div style="padding-top: 110px;">
    <a class="btn-more btn-lg" href="#second" role="button" style="margin-left:50%;"><font color="white">MORE</font></a>
    </div>
</div>
</div>

<div class="wrapper">
<div class="bgsecond">
<div class="container" id="second">
        <p style="padding-top: 70px; font-size: 50px;" align="center">Kelebihan Website Kami</p>
                    <div class="kelebihan" style="padding-top: 40px">
                        <table  align="center" cellpadding="15" >
                            <tr align="center">
                                <td>
                                    <img class="img-fluid" src="https://www.flaticon.com/svg/static/icons/svg/822/822225.svg" width="100">
                                 </td>

                                <td>
                                    <img class="img-fluid" src="https://www.flaticon.com/svg/static/icons/svg/942/942196.svg" width="100">
                                </td>

                                <td>
                                    <img class="img-fluid" src="https://www.flaticon.com/svg/static/icons/svg/2618/2618461.svg" width="100">
                                </td>

                            </tr>
                            <tr>
                                <td>
                                    <p class="pt-4">Referensi Nama Berasal dari 4 Bahasa : <br></p>
                            
                            </ul>
                                </td>


                                <td>
                                    <p class="pt-4">Setiap nama memiliki arti yang akurat berdasarkan nama masing-masing</p>
                                </td>

                                <td>
                                    <p class="pt-4">Tidak perlu repot mencari nama, hanya tinggal 1 Klik</p>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <ul>
                                <li>
                                    Bahasa Arab
                                </li>
                                <li>
                                    Bahasa Indonesia
                                </li>
                                <li>
                                    Bahasa Eropa
                                </li>
                                <li>
                                    Bahasa Sansekerta
                                </li>
                                </td>
                            </tr>
                        </table>
                    
                    </div>  
            </div>
</div>

<div class="wrapper">
    <div class="container" id="three">
        <hr class="hr-three">
        <p class="topthree">Tertarik mencoba untuk dicarikan oleh kami nama terbaik untuk si buah kecil anda</p>
    </div>
</div>

<br>
<br>
    
    <footer>
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babyGen\resources\views/index.blade.php ENDPATH**/ ?>