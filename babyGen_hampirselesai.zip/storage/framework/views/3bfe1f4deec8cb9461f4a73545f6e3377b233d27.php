	

	<?php $__env->startSection('content'); ?>

	<?php if(Session::has('post_created')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('post_created')); ?>

    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('post.create')); ?>" method="POST">
        
        
        <?php echo csrf_field(); ?>

        <h1>Form Inputan Nama</h1>

        <fieldset id="UserDataFields">
            <legend align="center">Silahkan Mengisi Nama Anda</legend>

            <div class="control-group">
                <label for="">Nama Anda : </label>
                <input type="text" name="nama_andaTambah" id="nama_andaTambah" value="">
            </div>

            <div class="control-group">
                <label for="">Asal Nama : </label>
                <input type="text" name="asal_namaTambah" id="asal_namaTambah" value="">
            </div>

            <div class="control-group">
                <label for="">Personality : </label>
                <input type="text" name="personalityTambah" id="personalityTambah" value="">
            </div>

            <div class="control-group">
                <label for="">Jenis Kelamin : </label>
                <input type="text" name="jenis_kelaminTambah" id="jenis_kelaminTambah" value="">
            </div>

            <div class="control-group">
                <label for="">Arti Nama : </label>
                <input type="text" name="arti_namaTambah" id="arti_namaTambah" value="">
            </div>

        </fieldset>

        <fieldset id="FormAction">
            <legend>Selesai mengisikan form?</legend>

            <input type="reset" value="Reset Data">
            <input type="submit" name="submit" value="Proses">
            
        </fieldset>

        <a href="/posts" class="btn btn-success" align="center">Cek Data</a>

    </form>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babyGen\resources\views/addname.blade.php ENDPATH**/ ?>