
    

    <?php $__env->startSection('content'); ?>

	<section style="padding-top: 120px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							All Post <br> <a href="/addname" class="btn btn-success"> Add New Name</a>
						</div>
						<div class="card-body">
							<?php if(Session::has('post_deleted')): ?>
							<div class="alert alert-success" role="alert">
								<?php echo e(Session::get('post_deleted')); ?>

							</div>
							<?php endif; ?>
							<table class="table table-striped">
								<thead>
									<tr>
										<th>ID</th>
										<th>Nama</th>
										<th>Asal Nama</th>
										<th>Personality</th>
										<th>Jenis Kelamin</th>
										<th>Arti Nama</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($post->id); ?></td>
										<td><?php echo e($post->nama); ?></td>
										<td><?php echo e($post->asal_nama); ?></td>
										<td><?php echo e($post->personality); ?></td>
										<td><?php echo e($post->jenis_kelamin); ?></td>
										<td><?php echo e($post->arti_nama); ?></td>
										<td>
											<button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Details</button>
											<a href="/delete-post/<?php echo e($post->id); ?>" class="btn btn-danger">Delete</a>
											<a href="/edit-post/<?php echo e($post->id); ?>" class="btn btn-success">Edit</a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>

		<div class="modal" id="myModal" tabindex="-1" role="dialog">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title">Details Information</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body" align="center">
		        <p>Nama : <?php echo e($post->nama); ?></p>
		        <p>Arti Nama : <?php echo e($post->asal_nama); ?></p>
		        <p>Personality : <?php echo e($post->personality); ?></p>
		        <p>Jenis Kelamin : <?php echo e($post->jenis_kelamin); ?></p>
		        <p>Arti Nama : <?php echo e($post->arti_nama); ?></p>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>



	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babyGen\resources\views/posts.blade.php ENDPATH**/ ?>