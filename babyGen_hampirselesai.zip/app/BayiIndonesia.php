<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BayiIndonesia extends Model
{
    protected $table = "bayiindonesia";
}
