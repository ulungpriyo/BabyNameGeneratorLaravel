<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BayiSansekerta extends Model
{
    protected $table = "bayisansekerta";
}
