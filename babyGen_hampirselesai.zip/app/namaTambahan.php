<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class namaTambahan extends Model
{
    protected $table = "nama_tambahans";
}
