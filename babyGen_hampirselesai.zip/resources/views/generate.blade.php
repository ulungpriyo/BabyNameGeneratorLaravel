

    @extends('layout.main')

    @section('content')

    <form action="generate" method="post">
        
        @csrf

        <h1>Form Inputan Nama</h1>

        <fieldset id="UserDataFields">
            <legend align="center">Silahkan Mengisi Nama Anda</legend>

            <div class="control-group">
                <label for="">Nama Anda : </label>
                <input type="text" name="nama_andaGenerate" id="nama_anda" value="" placeholder="Jika Ada">
            </div>

            <div class="control-group" >
                
                <label for="">Asal Nama : </label>
                <select name="operatorAsal" value="" required="">
                <option value="">-----Pilih Asal Nama-----</option>
                <option value="asalBa">Bayi Arab</option>
                <option value="asalBi">Bayi Indonesia</option>
                <option value="asalBe">Bayi Eropa</option>
                <option value="asalBs">Bayi Sansekerta</option>
                </select>
            </div>

            <div class="control-group">
                
                <label for="">Personality : </label>
                <select name="operatorPersonality" value="" required="">
                <option value="">-----Pilih Personality-----</option>
                <option value="Energetic">Energetic</option>
                <option value="Creative">Creative</option>
                <option value="Romantic">Romantic</option>
                <option value="Supportive">Supportive</option>
                </select>
            </div>

            <div class="control-group">
                
                <label for="">Jenis Kelamin : </label>
                <select name="operatorjenisKelamin" value="" required="">
                <option value="">-----Jenis Kelamin-----</option>
                <option value="L">Laki - Laki</option>
                <option value="P">Perempuan</option>
                </select>
            </div>

            <div class="control-group">
                
                <label for="">Kata : </label>
                <select name="operatorjumlahKata" value="" required="">
                <option value="">-----Jumlah Kata-----</option>
                <option value="1">Satu Kata</option>
                <option value="2">Dua Kata</option>
                </select>
            </div>

        </fieldset>

        <fieldset id="FormAction">
            <legend>Selesai mengisikan form?</legend>

            <input type="reset" value="Reset Data">
            <input type="submit" name="submit" value="Proses">
            
        </fieldset>

    </form>

<div class="container pt-4">
    <div>
    <p style="font-size: 30px;" align="center">Nama : {{ $result ?? '' }}</p>
    <p style="font-size: 30px;" align="center">Arti Nama : {{ $arti_nama  ?? '' }}</p> 
    </div>
</div>
    
    @endsection