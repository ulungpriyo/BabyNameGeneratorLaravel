<!DOCTYPE html>
<html>

    @extends('layout.header')
    
<body>

    @extends('layout.navbar')

    @yield('content')

</body>
</html>